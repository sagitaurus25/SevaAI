import json
import boto3
from typing import Dict, Any

ec2_client = boto3.client('ec2')

def lambda_handler(event, context):
    """EC2 Service Lambda - Handles all EC2 operations"""
    try:
        request = event.get('request', '').lower()
        operation = event.get('operation', '')
        parameters = event.get('parameters', {})
        
        if 'list' in request and 'instance' in request:
            return list_instances()
        elif 'start' in request and 'instance' in request:
            instance_id = parameters.get('instance_id', extract_instance_id(request))
            return start_instance(instance_id)
        elif 'stop' in request and 'instance' in request:
            instance_id = parameters.get('instance_id', extract_instance_id(request))
            return stop_instance(instance_id)
        elif 'reboot' in request and 'instance' in request:
            instance_id = parameters.get('instance_id', extract_instance_id(request))
            return reboot_instance(instance_id)
        elif 'describe' in request or 'details' in request:
            instance_id = parameters.get('instance_id', extract_instance_id(request))
            return describe_instance(instance_id)
        elif 'security' in request and 'group' in request:
            return list_security_groups()
        elif 'key' in request and 'pair' in request:
            return list_key_pairs()
        else:
            return {
                'error': 'EC2 operation not recognized',
                'supported_operations': [
                    'List all instances',
                    'Start instance i-1234567890abcdef0',
                    'Stop instance i-1234567890abcdef0',
                    'Reboot instance i-1234567890abcdef0',
                    'Describe instance i-1234567890abcdef0',
                    'List security groups',
                    'List key pairs'
                ]
            }
            
    except Exception as e:
        return {'error': f'EC2 service error: {str(e)}'}

def list_instances():
    """List all EC2 instances"""
    try:
        response = ec2_client.describe_instances()
        instances = []
        
        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                # Get instance name from tags
                name = 'N/A'
                for tag in instance.get('Tags', []):
                    if tag['Key'] == 'Name':
                        name = tag['Value']
                        break
                
                instances.append({
                    'instance_id': instance['InstanceId'],
                    'name': name,
                    'state': instance['State']['Name'],
                    'instance_type': instance['InstanceType'],
                    'public_ip': instance.get('PublicIpAddress', 'N/A'),
                    'private_ip': instance.get('PrivateIpAddress', 'N/A'),
                    'launch_time': instance['LaunchTime'].isoformat(),
                    'availability_zone': instance['Placement']['AvailabilityZone'],
                    'vpc_id': instance.get('VpcId', 'N/A'),
                    'subnet_id': instance.get('SubnetId', 'N/A')
                })
        
        # Group by state
        states = {}
        for instance in instances:
            state = instance['state']
            if state not in states:
                states[state] = 0
            states[state] += 1
        
        return {
            'operation': 'list_instances',
            'instances': instances,
            'count': len(instances),
            'states_summary': states,
            'success': True
        }
    except Exception as e:
        return {'error': f'Failed to list instances: {str(e)}'}

def start_instance(instance_id):
    """Start an EC2 instance"""
    if not instance_id:
        return {'error': 'Instance ID is required'}
    
    try:
        response = ec2_client.start_instances(InstanceIds=[instance_id])
        current_state = response['StartingInstances'][0]['CurrentState']['Name']
        previous_state = response['StartingInstances'][0]['PreviousState']['Name']
        
        return {
            'operation': 'start_instance',
            'instance_id': instance_id,
            'previous_state': previous_state,
            'current_state': current_state,
            'message': f'Instance {instance_id} is starting',
            'success': True
        }
    except Exception as e:
        return {'error': f'Failed to start instance {instance_id}: {str(e)}'}

def stop_instance(instance_id):
    """Stop an EC2 instance"""
    if not instance_id:
        return {'error': 'Instance ID is required'}
    
    try:
        response = ec2_client.stop_instances(InstanceIds=[instance_id])
        current_state = response['StoppingInstances'][0]['CurrentState']['Name']
        previous_state = response['StoppingInstances'][0]['PreviousState']['Name']
        
        return {
            'operation': 'stop_instance',
            'instance_id': instance_id,
            'previous_state': previous_state,
            'current_state': current_state,
            'message': f'Instance {instance_id} is stopping',
            'success': True
        }
    except Exception as e:
        return {'error': f'Failed to stop instance {instance_id}: {str(e)}'}

def reboot_instance(instance_id):
    """Reboot an EC2 instance"""
    if not instance_id:
        return {'error': 'Instance ID is required'}
    
    try:
        ec2_client.reboot_instances(InstanceIds=[instance_id])
        return {
            'operation': 'reboot_instance',
            'instance_id': instance_id,
            'message': f'Instance {instance_id} is rebooting',
            'success': True
        }
    except Exception as e:
        return {'error': f'Failed to reboot instance {instance_id}: {str(e)}'}

def describe_instance(instance_id):
    """Get detailed information about an instance"""
    if not instance_id:
        return {'error': 'Instance ID is required'}
    
    try:
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        instance = response['Reservations'][0]['Instances'][0]
        
        # Get instance name
        name = 'N/A'
        for tag in instance.get('Tags', []):
            if tag['Key'] == 'Name':
                name = tag['Value']
                break
        
        return {
            'operation': 'describe_instance',
            'instance_details': {
                'instance_id': instance['InstanceId'],
                'name': name,
                'state': instance['State']['Name'],
                'instance_type': instance['InstanceType'],
                'public_ip': instance.get('PublicIpAddress', 'N/A'),
                'private_ip': instance.get('PrivateIpAddress', 'N/A'),
                'public_dns': instance.get('PublicDnsName', 'N/A'),
                'launch_time': instance['LaunchTime'].isoformat(),
                'availability_zone': instance['Placement']['AvailabilityZone'],
                'vpc_id': instance.get('VpcId', 'N/A'),
                'subnet_id': instance.get('SubnetId', 'N/A'),
                'security_groups': [sg['GroupName'] for sg in instance['SecurityGroups']],
                'key_name': instance.get('KeyName', 'N/A'),
                'architecture': instance.get('Architecture', 'N/A'),
                'root_device_type': instance.get('RootDeviceType', 'N/A')
            },
            'success': True
        }
    except Exception as e:
        return {'error': f'Failed to describe instance {instance_id}: {str(e)}'}

def list_security_groups():
    """List all security groups"""
    try:
        response = ec2_client.describe_security_groups()
        groups = []
        
        for group in response['SecurityGroups']:
            groups.append({
                'group_id': group['GroupId'],
                'group_name': group['GroupName'],
                'description': group['Description'],
                'vpc_id': group.get('VpcId', 'N/A'),
                'inbound_rules': len(group['IpPermissions']),
                'outbound_rules': len(group['IpPermissionsEgress'])
            })
        
        return {
            'operation': 'list_security_groups',
            'security_groups': groups,
            'count': len(groups),
            'success': True
        }
    except Exception as e:
        return {'error': f'Failed to list security groups: {str(e)}'}

def list_key_pairs():
    """List all key pairs"""
    try:
        response = ec2_client.describe_key_pairs()
        key_pairs = []
        
        for key_pair in response['KeyPairs']:
            key_pairs.append({
                'key_name': key_pair['KeyName'],
                'key_fingerprint': key_pair['KeyFingerprint'],
                'key_type': key_pair.get('KeyType', 'rsa')
            })
        
        return {
            'operation': 'list_key_pairs',
            'key_pairs': key_pairs,
            'count': len(key_pairs),
            'success': True
        }
    except Exception as e:
        return {'error': f'Failed to list key pairs: {str(e)}'}

def extract_instance_id(request):
    """Extract instance ID from natural language request"""
    words = request.split()
    for word in words:
        if word.startswith('i-') and len(word) == 19:  # Standard instance ID format
            return word
    return None